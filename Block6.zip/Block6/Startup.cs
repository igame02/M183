﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Block6.Startup))]
namespace Block6
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
